
# factorial of 5

n = 5;
i = 0;
f = 1;

while (i != n) {
 i = i + 1;
 f = f * i;
};

print f;

