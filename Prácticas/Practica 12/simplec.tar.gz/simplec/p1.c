
# example of an if statement

n = 5;

if (n % 2 == 0) print 0 else print 1;

