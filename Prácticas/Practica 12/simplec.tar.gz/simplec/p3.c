
# factorial of 5

n = 5;
f = 1;

for (i = 1; i <= n; i = i+1) {
  f = f * i;
};

print f;

