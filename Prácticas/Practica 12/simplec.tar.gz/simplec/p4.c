
# example of illegal statement in init section of for loop

i = 1;

for (print i; i <= 5; i=i+1) {
  print i;
};

